# League of Bums Theme

The visual theme is now styled as an old-school football sports-network site.

## Main theme file
Edit `src/styles.css`.

### Master colors
- `--color-field` — overall background
- `--color-field-raised` — panels/cards
- `--color-field-line` — borders
- `--color-parchment` — primary text
- `--color-parchment-dim` — secondary text
- `--color-mustard` — primary red broadcast accent
- `--color-rust` — secondary green accent
- `--color-turf` — field green

### Fonts
- Display: Oswald
- Body: Roboto
- Stats/numbers: Roboto Mono

The added broadcast layer is at the bottom of `src/styles.css`, so it can be adjusted independently from the original component styling.
